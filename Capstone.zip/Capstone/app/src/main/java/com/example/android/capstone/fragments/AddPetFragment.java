package com.example.android.capstone.fragments;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.android.capstone.Pet;
import com.example.android.capstone.PetAdapter;
import com.example.android.capstone.R;
import com.example.android.capstone.activities.MainActivity;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;

import org.w3c.dom.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;
import static com.example.android.capstone.Constants.*;

public class AddPetFragment extends Fragment {

    private Context mContext;
    public static final int RC_SIGN_IN = 1;


    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mPetsDatabaseReference;
    private FirebaseStorage mFirebaseStorage;
    private StorageReference mPetPhotosStorageReference;
    private ChildEventListener mChildEventListener;
    private String userName;
    private String userNameUid;
    private String locationName;
    private Double locationLongitude;
    private Double locationLatitude;

    private EditText name;
    private EditText breed;
    private EditText startDate;
    private EditText endDate;
    private EditText phone;
    private EditText email;
    private TextView locationTV;
    private TextView owner;
    private ImageButton image;

    private Uri selectedImageUri;

    public AddPetFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userName = getArguments().getString(USER_NAME);
        userNameUid = getArguments().getString(USER_ID);
        locationName = getArguments().getString(LOCATION_NAME);
        locationLongitude = getArguments().getDouble(LOCATION_LONGITUDE);
        locationLatitude = getArguments().getDouble(LOCATION_LATITUDE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_pet, container, false);
        mContext = container.getContext();

        //Initialize Firebase
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mPetsDatabaseReference = mFirebaseDatabase.getReference().child("pets");
        mFirebaseStorage = FirebaseStorage.getInstance();
        mPetPhotosStorageReference = mFirebaseStorage.getReference().child("pet_photos");
        //attachDatabaseReadListener();

        image = view.findViewById(R.id.pet_detail_image);
        name = view.findViewById(R.id.pet_detail_name);
        breed = view.findViewById(R.id.pet_detail_breed);
        startDate = view.findViewById(R.id.pet_detail_start_date);
        endDate = view.findViewById(R.id.pet_detail_end_date);
        phone = view.findViewById(R.id.pet_detail_phone);
        email = view.findViewById(R.id.pet_detail_email);
        locationTV = view.findViewById(R.id.pet_detail_location);
        owner = view.findViewById(R.id.pet_detail_owner);

        owner.setText(userName);
        locationTV.setText(locationName);

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/jpeg");
                intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
                startActivityForResult(Intent.createChooser(intent, "Complete action using"), RC_PHOTO_PICKER);
            }
        });
        startDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar now = Calendar.getInstance();
                DatePickerDialog dpd = DatePickerDialog.newInstance(
                        onDateSetListener,
                        now.get(Calendar.YEAR), // Initial year selection
                        now.get(Calendar.MONTH), // Initial month selection
                        now.get(Calendar.DAY_OF_MONTH) // Inital day selection
                );
                // If you're calling this from a support Fragment
                dpd.show(requireFragmentManager(), "Datepickerdialog");
            }
        });

        Button saveButton = view.findViewById(R.id.pet_detail_save);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                savePetWithImage();
            }
        });


        return view;
    }

    private void savePetWithImage() {
        final StorageReference photoRef = mPetPhotosStorageReference.child(selectedImageUri.getLastPathSegment());
        photoRef.putFile(selectedImageUri)
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(mContext, "Failure to get Photo", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnSuccessListener(getActivity(), new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        //When the image has successfully uploaded, get its download URL
                        photoRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                String id = mPetsDatabaseReference.push().getKey();
                                Pet newPet = new Pet(id, name.getText().toString(), breed.getText().toString(),
                                        locationTV.getText().toString(), locationLongitude, locationLatitude,
                                        startDate.getText().toString(), endDate.getText().toString(),
                                        phone.getText().toString(), email.getText().toString(),
                                        userName, userNameUid, uri.toString(), String.valueOf(Calendar.getInstance().getTimeInMillis()));
                                mPetsDatabaseReference.child(id).setValue(newPet);
                                Toast.makeText(mContext, "Pet saved", Toast.LENGTH_SHORT).show();

                            }
                        });
                    }
                });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            if (resultCode == RESULT_OK) {
                // Sign-in succeeded, set up the UI
                Toast.makeText(mContext, "Signed in!", Toast.LENGTH_SHORT).show();
            } else if (resultCode == RESULT_CANCELED) {
                // Sign in was canceled by the user, finish the activity
                Toast.makeText(mContext, "Sign in canceled", Toast.LENGTH_SHORT).show();
                //finish();
            }
        } else if (requestCode == RC_PHOTO_PICKER && resultCode == RESULT_OK) {
            selectedImageUri = data.getData();
            Glide.with(mContext)
                    .load(selectedImageUri)
                    .into(image);
        }
    }

    private DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
            String date = dayOfMonth+"/"+(monthOfYear+1)+"/"+year;
            startDate.setText(date);
        }
    };



//    private String getCurrentLocationName(Double lat, Double lon) {
//        String cityName = "";
//        Geocoder geocoder = new Geocoder(mContext, Locale.getDefault());
//        List<Address> addresses;
//        try {
//            addresses = geocoder.getFromLocation(lat, lon, 10);
//            if (addresses.size() > 0) {
//                for (Address add : addresses) {
//                    if (add.getLocality() != null && add.getLocality().length() > 0) {
//                        cityName = add.getLocality();
//                        break;
//                    }
//
//                }
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return cityName;
//    }
//
//    private void getCurrentLocation(){
//        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M && mContext.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1000);
//        } else {
//            LocationManager locationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
//            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//            try {
//                String city = getCurrentLocationName(location.getLatitude(), location.getLongitude());
//                locationTV.setText(city);
//            } catch (Exception e){
//                e.printStackTrace();
//                Toast.makeText(mContext,"Location not found!", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        switch (requestCode){
//            case 1000:{
//                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    LocationManager locationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
//                    Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//                    try {
//                        String city = getCurrentLocationName(location.getLatitude(), location.getLongitude());
//                        locationTV.setText(city);
//                    } catch (Exception e){
//                        e.printStackTrace();
//                        Toast.makeText(mContext,"Location not found!", Toast.LENGTH_SHORT).show();
//                    }
//
//                }
//            }
//        }
//    }

    //    private void attachDatabaseReadListener() {
//        if (mChildEventListener == null) {
//            mChildEventListener = new ChildEventListener() {
//                @Override
//                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
////                    Pet pet = dataSnapshot.getValue(Pet.class);
//                    //mMessageAdapter.add(friendlyMessage);
//                }
//
//                public void onChildChanged(DataSnapshot dataSnapshot, String s) {
//                }
//
//                public void onChildRemoved(DataSnapshot dataSnapshot) {
//                }
//
//                public void onChildMoved(DataSnapshot dataSnapshot, String s) {
//                }
//
//                public void onCancelled(DatabaseError databaseError) {
//                }
//            };
//            mPetsDatabaseReference.addChildEventListener(mChildEventListener);
//        }
//    }
//
//    private void detachDatabaseReadListener() {
//        if (mChildEventListener != null) {
//            mPetsDatabaseReference.removeEventListener(mChildEventListener);
//            mChildEventListener = null;
//        }
//    }
//
//    @Override
//    public void onPause() {
//        super.onPause();
//        detachDatabaseReadListener();
//    }
}
