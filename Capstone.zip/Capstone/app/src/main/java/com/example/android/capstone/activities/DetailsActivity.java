package com.example.android.capstone.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.android.capstone.Pet;
import com.example.android.capstone.R;

import static com.example.android.capstone.Constants.*;

public class DetailsActivity extends AppCompatActivity {

    private Pet currentPet;
    private ImageView petImage;
    private View petNameLayout;
    private TextView petBreed;
    private TextView petPickUp;
    private TextView petDropOff;
    private TextView petOwner;
    private TextView petLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Intent intent = getIntent();
        if (intent.hasExtra(CURRENT_PET)){
            currentPet = intent.getParcelableExtra(CURRENT_PET);
        }

        Toolbar toolbar = findViewById(R.id.details_toolbar);
        toolbar.setTitle(currentPet.getName());
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        petImage = findViewById(R.id.pet_detail_image);
        petNameLayout = findViewById(R.id.pet_detail_name_layout);
        petBreed = findViewById(R.id.pet_detail_breed);
        petPickUp = findViewById(R.id.pet_detail_start_date);
        petDropOff = findViewById(R.id.pet_detail_end_date);
        petOwner = findViewById(R.id.pet_detail_owner);
        petLocation = findViewById(R.id.pet_detail_location);

        Glide.with(this)
                .load(currentPet.getImageUrl())
                .into(petImage);
        petNameLayout.setVisibility(View.GONE);
        petBreed.setText(currentPet.getBreed());
        petBreed.setEnabled(false);
        petPickUp.setText(currentPet.getStartDate());
        petPickUp.setEnabled(false);
        petDropOff.setText(currentPet.getEndDate());
        petDropOff.setEnabled(false);
        petOwner.setText(currentPet.getOwner());
        petLocation.setText(currentPet.getLocation());
    }
}
