package com.example.android.capstone;

public final class Constants {
    public final static String USER_NAME = "USER_NAME";
    public final static String USER_ID = "USER_ID";
    public final static String LOCATION_NAME = "LOCATION_NAME";
    public final static String LOCATION_LONGITUDE = "LOCATION_LONGITUDE";
    public final static String LOCATION_LATITUDE = "LOCATION_LATITUDE";
    public final static String CURRENT_PET = "CURRENT_PET";
    public final static int EDIT_REQUEST_CODE = 300;
    public static final int RC_PHOTO_PICKER = 2;
}
