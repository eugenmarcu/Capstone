package com.example.android.capstone.activities;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.android.capstone.PetAdapter;
import com.example.android.capstone.R;
import com.example.android.capstone.fragments.AddPetFragment;
import com.example.android.capstone.fragments.HomeFragment;
import com.example.android.capstone.fragments.MyPetsFragment;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import static com.example.android.capstone.Constants.*;

public class MainActivity extends AppCompatActivity {

    public static final int RC_SIGN_IN = 1;

    //firebase
    private FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;

    private FirebaseUser signedInUser;
    private String locationName;
    private Double locationLongitude;
    private Double locationLatitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //get current Location;
        getCurrentLocation();

        //Initialize Firebase
        mFirebaseAuth = FirebaseAuth.getInstance();

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    signedInUser = user; user.getUid();
                    //onSignedInInitialize(user.getDisplayName());
                } else {
                    // User is signed out
                    //onSignedOutCleanup();
                    startActivityForResult(
                            AuthUI.getInstance()
                                    .createSignInIntentBuilder()
                                    .setIsSmartLockEnabled(false)
                                    .setAvailableProviders(
                                            Arrays.asList(new AuthUI.IdpConfig.EmailBuilder().build(),
                                                    new AuthUI.IdpConfig.GoogleBuilder().build()))
                                    .setLogo(R.drawable.pets)
                                    .setTheme(R.style.AuthenticationTheme)
                                    .build(),
                            RC_SIGN_IN);
                }

            }
        };

        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.content_main_frame, new HomeFragment())
                .commit();

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nav_view);
        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        item.setChecked(true);
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        Bundle args = new Bundle();
                        args.putString(USER_NAME, signedInUser.getDisplayName());
                        args.putString(USER_ID, signedInUser.getUid());
                        args.putString(LOCATION_NAME, locationName);
                        args.putDouble(LOCATION_LONGITUDE, locationLongitude);
                        args.putDouble(LOCATION_LATITUDE, locationLatitude);

                        switch (item.getItemId()) {
                            case R.id.action_home:
                                fragmentManager.beginTransaction()
                                        .replace(R.id.content_main_frame, new HomeFragment())
                                        .commit();
                                break;
                            case R.id.action_add_pet:
                                AddPetFragment addPetfragment = new AddPetFragment();
                                addPetfragment.setArguments(args);
                                fragmentManager.beginTransaction()
                                        .replace(R.id.content_main_frame, addPetfragment)
                                        .commit();
                                break;
                            case R.id.action_my_pets:
                                MyPetsFragment myPetsFragment = new MyPetsFragment();
                                myPetsFragment.setArguments(args);
                                fragmentManager.beginTransaction()
                                        .replace(R.id.content_main_frame, myPetsFragment)
                                        .commit();
                                break;
                        }
                        return false;
                    }
                });


    }

    @Override
    protected void onResume() {
        super.onResume();
        mFirebaseAuth.addAuthStateListener(mAuthStateListener);
    }


    @Override
    protected void onPause() {
        super.onPause();
        if (mAuthStateListener != null) {
            mFirebaseAuth.removeAuthStateListener(mAuthStateListener);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            if (resultCode == RESULT_OK) {
                // Sign-in succeeded, set up the UI
                Toast.makeText(this, "Signed in!", Toast.LENGTH_SHORT).show();
            } else if (resultCode == RESULT_CANCELED) {
                // Sign in was canceled by the user, finish the activity
                Toast.makeText(this, "Sign in canceled", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.sign_out_menu:
                AuthUI.getInstance().signOut(this);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private String getCurrentLocationName(Double lat, Double lon) {
        String cityName = "";
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses;
        try {
            addresses = geocoder.getFromLocation(lat, lon, 10);
            if (addresses.size() > 0) {
                for (Address add : addresses) {
                    if (add.getLocality() != null && add.getLocality().length() > 0) {
                        cityName = add.getLocality();
                        break;
                    }

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cityName;
    }

    private void getCurrentLocation(){
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1000);
        } else {
            LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            try {
                locationName = getCurrentLocationName(location.getLatitude(), location.getLongitude());
                locationLatitude = location.getLatitude();
                locationLongitude = location.getLongitude();
            } catch (Exception e){
                e.printStackTrace();
                Toast.makeText(this,"Location not found!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case 1000:{
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                    Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    try {
                        locationName = getCurrentLocationName(location.getLatitude(), location.getLongitude());
                        locationLatitude = location.getLatitude();
                        locationLongitude = location.getLongitude();
                    } catch (Exception e){
                        e.printStackTrace();
                        Toast.makeText(this,"Location not found!", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        }
    }
}
