package com.example.android.capstone.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.android.capstone.Pet;
import com.example.android.capstone.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Calendar;

import static com.example.android.capstone.Constants.*;


public class EditActivity extends AppCompatActivity {

    private Pet currentPet;

    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mPetsDatabaseReference;
    private FirebaseStorage mFirebaseStorage;
    private StorageReference mPetPhotosStorageReference;

    private Uri selectedImageUri;

    private EditText name;
    private EditText breed;
    private EditText startDate;
    private EditText endDate;
    private EditText phone;
    private EditText email;
    private TextView locationTV;
    private TextView owner;
    private ImageButton image;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        Intent intent = getIntent();
        if (intent.hasExtra(CURRENT_PET)) {
            currentPet = intent.getParcelableExtra(CURRENT_PET);
        }

        Toolbar toolbar = findViewById(R.id.details_toolbar);
        toolbar.setTitle("Edit");
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        image = findViewById(R.id.pet_detail_image);
        name = findViewById(R.id.pet_detail_name);
        breed = findViewById(R.id.pet_detail_breed);
        startDate = findViewById(R.id.pet_detail_start_date);
        endDate = findViewById(R.id.pet_detail_end_date);
        phone = findViewById(R.id.pet_detail_phone);
        email = findViewById(R.id.pet_detail_email);
        locationTV = findViewById(R.id.pet_detail_location);
        owner = findViewById(R.id.pet_detail_owner);

        Glide.with(this)
                .load(currentPet.getImageUrl())
                .into(image);

        name.setText(currentPet.getName());
        breed.setText(currentPet.getBreed());
        startDate.setText(currentPet.getStartDate());
        endDate.setText(currentPet.getEndDate());
        phone.setText(currentPet.getPhone());
        email.setText(currentPet.getEmail());
        locationTV.setText(currentPet.getLocation());
        owner.setText(currentPet.getOwner());

        //Initialize Firebase
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mPetsDatabaseReference = mFirebaseDatabase.getReference().child("pets");
        mFirebaseStorage = FirebaseStorage.getInstance();
        mPetPhotosStorageReference = mFirebaseStorage.getReference().child("pet_photos");

//        image.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
//                intent.setType("image/jpeg");
//                intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
//                startActivityForResult(Intent.createChooser(intent, "Complete action using"), RC_PHOTO_PICKER);
//            }
//        });

        Button saveBtn = findViewById(R.id.pet_detail_save);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                savePetWithImage();
                sendActivityResult();
            }
        });

        Button deleteBtn = findViewById(R.id.pet_detail_delete);
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(EditActivity.this)
                        .setTitle("Delete pet")
                        .setMessage("Are you sure you want to delete this pet?")

                        // Specifying a listener allows you to take an action before dismissing the dialog.
                        // The dialog is automatically dismissed when a dialog button is clicked.
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Continue with delete operation
                                mPetsDatabaseReference.child(currentPet.getId()).removeValue();
                                sendActivityResult();
                            }
                        })

                        // A null listener allows the button to dismiss the dialog and take no further action.
                        .setNegativeButton("No", null)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_PHOTO_PICKER && resultCode == RESULT_OK) {
            selectedImageUri = data.getData();
            Glide.with(this)
                    .load(selectedImageUri)
                    .into(image);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void sendActivityResult() {
        Intent returnIntent = new Intent();
        returnIntent.putExtra("result", EDIT_REQUEST_CODE);
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }

    private Pet getEditedPet() {
        currentPet.setName(name.getText().toString());
        currentPet.setBreed(breed.getText().toString());
        currentPet.setStartDate(startDate.getText().toString());
        currentPet.setEndDate(endDate.getText().toString());
        currentPet.setPhone(phone.getText().toString());
        currentPet.setEmail(email.getText().toString());
        if (selectedImageUri != null)
            currentPet.setImageUrl(selectedImageUri.toString());
        return currentPet;
    }

    private void savePetWithImage() {
        if (selectedImageUri == null) {
            currentPet = getEditedPet();
            mPetsDatabaseReference.child(currentPet.getId()).setValue(currentPet);
            Toast.makeText(EditActivity.this, "Pet saved", Toast.LENGTH_SHORT).show();
        } else {
            final StorageReference photoRef = mPetPhotosStorageReference.child(selectedImageUri.getLastPathSegment());
            photoRef.putFile(selectedImageUri)
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(EditActivity.this, "Failure to get Photo", Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnSuccessListener(this, new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            //When the image has successfully uploaded, get its download URL
                            photoRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    currentPet = getEditedPet();
                                    currentPet.setImageUrl(uri.toString());
                                    mPetsDatabaseReference.child(currentPet.getId()).setValue(currentPet);
                                    Toast.makeText(EditActivity.this, "Pet saved", Toast.LENGTH_SHORT).show();

                                }
                            });
                        }
                    });
        }
    }
}
