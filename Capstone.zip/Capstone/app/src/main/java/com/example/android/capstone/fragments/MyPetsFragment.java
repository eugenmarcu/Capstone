package com.example.android.capstone.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.example.android.capstone.Pet;
import com.example.android.capstone.PetAdapter;
import com.example.android.capstone.R;
import com.example.android.capstone.activities.EditActivity;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.example.android.capstone.Constants.*;

public class MyPetsFragment extends Fragment implements PetAdapter.ItemClickListener {

    private Context mContext;

    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mPetsDatabaseReference;
    private ValueEventListener valueEventListener;
    private Query query;

    private List<Pet> petList;
    private RecyclerView petRecyclerView;
    private PetAdapter petAdapter;
    private ImageView emptyView;
    private ProgressBar progressBar;

    private String userName;
    private String userUid;


    public MyPetsFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userName = getArguments().getString(USER_NAME);
        userUid = getArguments().getString(USER_ID);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        mContext = container.getContext();

        //Initialize Firebase
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mPetsDatabaseReference = mFirebaseDatabase.getReference().child("pets");
        //query the data by user name
        queryDataByUserName();

        int numberOfColumns = 2;
        petList = new ArrayList<>();

        petRecyclerView = view.findViewById(R.id.list_rv);
        petRecyclerView.setLayoutManager(new StaggeredGridLayoutManager(numberOfColumns, 1));
        petAdapter = new PetAdapter(mContext, petList);
        petAdapter.setClickListener(this);
        petRecyclerView.setAdapter(petAdapter);

        emptyView = view.findViewById(R.id.empty_view);
        progressBar = view.findViewById(R.id.progress_bar);
        progressBar.setVisibility(View.VISIBLE);

        return view;
    }

    private void queryDataByUserName() {
        if (valueEventListener != null) {
            query.removeEventListener(valueEventListener);
        }
        query = mPetsDatabaseReference.orderByChild("ownerUid").equalTo(userUid);
        valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                progressBar.setVisibility(View.GONE);
                if (dataSnapshot.exists()) {
                    for (DataSnapshot data : dataSnapshot.getChildren()) {
                        Pet pet = data.getValue(Pet.class);
                        petAdapter.add(pet);
                    }

                    if (petAdapter.getItemCount() > 0)
                        emptyView.setVisibility(View.GONE);
                    else
                        emptyView.setVisibility(View.VISIBLE);
                } else
                    emptyView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };
        query.addListenerForSingleValueEvent(valueEventListener);

    }

    @Override
    public void onItemClick(View view, int position) {
        Intent intent = new Intent(mContext, EditActivity.class);
        Pet currentPet = petAdapter.getItem(position);
        intent.putExtra(CURRENT_PET, currentPet);
        startActivityForResult(intent, EDIT_REQUEST_CODE);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == EDIT_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            petAdapter.clearAll();
            queryDataByUserName();
        }
    }
}
