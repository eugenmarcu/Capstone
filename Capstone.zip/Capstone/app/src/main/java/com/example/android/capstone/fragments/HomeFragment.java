package com.example.android.capstone.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.example.android.capstone.activities.DetailsActivity;
import com.example.android.capstone.Pet;
import com.example.android.capstone.PetAdapter;
import com.example.android.capstone.R;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.example.android.capstone.Constants.*;

public class HomeFragment extends Fragment implements PetAdapter.ItemClickListener {

    private Context mContext;

    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mPetsDatabaseReference;
    private Query query;
    private ValueEventListener mEventListener;

    private List<Pet> petList;
    private RecyclerView petRecyclerView;
    private PetAdapter petAdapter;
    private ImageView emptyView;
    private ProgressBar progressBar;

    public HomeFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        mContext = container.getContext();

        //Initialize Firebase
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mPetsDatabaseReference = mFirebaseDatabase.getReference().child("pets");
        query = mPetsDatabaseReference.orderByChild("timestamp").limitToLast(2);
        attachDatabaseReadListener();

        int numberOfColumns = 2;
        petList = new ArrayList<>();
        petRecyclerView = view.findViewById(R.id.list_rv);
        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(numberOfColumns, 1);
        //descending from timestamp
        //layoutManager.setReverseLayout(true);
        petRecyclerView.setLayoutManager(layoutManager);
        petAdapter = new PetAdapter(mContext, petList);
        petAdapter.setClickListener(this);
        petRecyclerView.setAdapter(petAdapter);

        emptyView = view.findViewById(R.id.empty_view);
        progressBar = view.findViewById(R.id.progress_bar);
        progressBar.setVisibility(View.VISIBLE);

        return view;
    }

    @Override
    public void onItemClick(View view, int position) {
        Intent intent = new Intent(mContext, DetailsActivity.class);
        Pet currentPet = petAdapter.getItem(position);
        intent.putExtra(CURRENT_PET, currentPet);
        startActivity(intent);
    }

    private void attachDatabaseReadListener() {
        if (mEventListener == null) {
            mEventListener = new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    progressBar.setVisibility(View.GONE);
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot data : dataSnapshot.getChildren()) {
                            Pet pet = data.getValue(Pet.class);
                            petAdapter.add(pet);
                            Collections.reverse(petList);
                        }

                        if (petAdapter.getItemCount() > 0)
                            emptyView.setVisibility(View.GONE);
                        else
                            emptyView.setVisibility(View.VISIBLE);
                    } else
                        emptyView.setVisibility(View.VISIBLE);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            };
        }

        //mPetsDatabaseReference.addChildEventListener(mChildEventListener);
        query.addValueEventListener(mEventListener);


    }

    private void detachDatabaseReadListener() {
        if (mEventListener != null) {
            query.removeEventListener(mEventListener);
            mEventListener = null;
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        detachDatabaseReadListener();
    }
}
